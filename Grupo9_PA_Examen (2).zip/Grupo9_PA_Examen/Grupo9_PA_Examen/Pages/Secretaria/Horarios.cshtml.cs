﻿namespace Grupo9_PA_Examen.Pages.Secretaria
{
    public class Horarios
    {
    }
}
