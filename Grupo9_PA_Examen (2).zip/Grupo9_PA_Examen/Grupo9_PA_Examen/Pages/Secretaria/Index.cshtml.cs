﻿using Grupo9_PA_Examen.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Grupo9_PA_Examen.Pages.Secretaria
{
    public class IndexModel : PageModel
    {

        public void OnGet()
        {
            
        }
    }
}