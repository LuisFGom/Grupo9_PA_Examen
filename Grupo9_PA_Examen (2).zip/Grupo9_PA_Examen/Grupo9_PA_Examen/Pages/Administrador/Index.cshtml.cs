﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Grupo9_PA_Examen.Pages.Administrador
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}